package com.mobevolution;

import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.DefaultAttributes;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraftforge.common.Tags;
import net.minecraftforge.registries.ForgeRegistries;

/** Clasificacion de jefes y nivel maximo de cada entidad (unica fuente de verdad). */
public final class BossRules {
    public static final ResourceLocation WARDEN = new ResourceLocation("minecraft", "warden");

    public enum Kind { NORMAL, VANILLA_BOSS, MODDED_BOSS, STRONG_BOSS }

    private BossRules() {}

    private static boolean matches(List<? extends String> list, ResourceLocation id) {
        return list.contains(id.toString()) || list.contains(id.getNamespace() + ":*");
    }

    /** Jefe por etiqueta: forge:bosses, o algun tag / id que se llame boss, bosses o ..._boss. */
    private static boolean isBossTagged(EntityType<?> type) {
        if (type.is(Tags.EntityTypes.BOSSES)) return true;
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(type);
        if (id != null && isBossName(id.getPath())) return true;
        return type.builtInRegistryHolder().tags().anyMatch(t -> isBossName(t.location().getPath()));
    }

    private static boolean isBossName(String path) {
        int slash = path.lastIndexOf('/');
        String n = slash >= 0 ? path.substring(slash + 1) : path;
        return n.equals("boss") || n.equals("bosses") || n.endsWith("_boss") || n.endsWith("_bosses");
    }

    public static Kind kind(EntityType<?> type, double baseHealth) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(type);
        if (id == null) return Kind.NORMAL;
        boolean listed = matches(Config.LIMITED_BOSSES.get(), id);
        if (!listed && !isBossTagged(type)) return Kind.NORMAL;
        boolean vanilla = id.getNamespace().equals("minecraft");
        if (vanilla && !listed) return Kind.VANILLA_BOSS;
        double threshold = Config.STRONG_BOSS_HEALTH.get();
        if (!vanilla && threshold > 0.0 && baseHealth > threshold) return Kind.STRONG_BOSS;
        return Kind.MODDED_BOSS;
    }

    /** Vida base por defecto de un tipo de entidad (para los comandos, sin necesidad de una instancia). */
    @SuppressWarnings("unchecked")
    public static double defaultBaseHealth(EntityType<?> type) {
        try {
            return DefaultAttributes.getSupplier((EntityType<? extends LivingEntity>) type).getBaseValue(Attributes.MAX_HEALTH);
        } catch (Throwable t) {
            return 0.0;
        }
    }

    public static boolean isBoss(EntityType<?> type) {
        return kind(type, defaultBaseHealth(type)) != Kind.NORMAL;
    }

    public static boolean isVanillaBoss(EntityType<?> type) {
        return kind(type, defaultBaseHealth(type)) == Kind.VANILLA_BOSS;
    }

    /**
     * Nivel maximo. Prioridad:
     * 1) valor personalizado (/mobevolution config mob <mob> maxlevel)
     * 2) Warden = 1
     * 3) jefe de Minecraft = vanillaBossMaxLevel (80); jefe de mod = moddedBossMaxLevel (30);
     *    jefe de mod con mucha vida = strongBossMaxLevel (30)
     * 4) mob normal = maxMobLevel
     */
    public static int maxLevel(EntityType<?> type, double baseHealth) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(type);
        if (id != null) {
            Integer custom = MobOverrides.maxLevel(id);
            if (custom != null) return custom;
            if (id.equals(WARDEN)) return 1;
        }
        int cap = switch (kind(type, baseHealth)) {
            case VANILLA_BOSS -> Config.VANILLA_BOSS_MAX_LEVEL.get();
            case MODDED_BOSS -> Config.MODDED_BOSS_MAX_LEVEL.get();
            case STRONG_BOSS -> Config.STRONG_BOSS_MAX_LEVEL.get();
            default -> Config.MAX_LEVEL.get();
        };
        return Math.min(cap, Config.MAX_LEVEL.get());
    }

    public static int maxLevel(EntityType<?> type) {
        return maxLevel(type, defaultBaseHealth(type));
    }
}
