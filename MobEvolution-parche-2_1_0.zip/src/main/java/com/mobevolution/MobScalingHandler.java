package com.mobevolution;

import com.mobevolution.BossRules.Kind;
import java.util.List;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

public class MobScalingHandler {
    public static final String TAG_LEVEL = "mobevolution_level";
    public static final String TAG_DMG = "mobevolution_dmg";

    private static final UUID HEALTH_ID = UUID.fromString("a1b2c3d4-0001-4000-8000-00000000e001");
    private static final UUID OLD_DAMAGE_ID = UUID.fromString("a1b2c3d4-0002-4000-8000-00000000e002");
    private static final UUID SPEED_ID = UUID.fromString("a1b2c3d4-0003-4000-8000-00000000e003");
    private static final UUID ARMOR_ID = UUID.fromString("a1b2c3d4-0004-4000-8000-00000000e004");

    // ------------------------------------------------------------------ eventos

    @SubscribeEvent
    public void onJoin(EntityJoinLevelEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!(event.getEntity() instanceof Mob mob)) return;

        CompoundTag data = mob.getPersistentData();
        if (data.contains(TAG_LEVEL)) {
            migrate(mob, data);
            return;
        }
        Kind kind = kindOf(mob);
        if (!shouldScale(mob, kind)) return;

        int lvl = computeLevel(level, mob);
        data.putInt(TAG_LEVEL, lvl);
        applyStats(mob, lvl, kind != Kind.NORMAL, true);

        if (Config.SHOW_LEVEL_IN_NAME.get() && !mob.hasCustomName()) {
            mob.setCustomName(Component.literal("[Lv." + lvl + "] ").append(mob.getType().getDescription()));
            mob.setCustomNameVisible(false);
        }
    }

    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        Entity src = event.getSource().getEntity();
        if (src instanceof Mob attacker && attacker != event.getEntity()) {
            CompoundTag d = attacker.getPersistentData();
            if (d.contains(TAG_DMG)) {
                event.setAmount((float) (event.getAmount() * d.getDouble(TAG_DMG)));
            }
        }
    }

    @SubscribeEvent
    public void onXp(LivingExperienceDropEvent event) {
        CompoundTag data = event.getEntity().getPersistentData();
        if (!data.contains(TAG_LEVEL)) return;
        double mult = Math.min(3.0, 1.0 + (data.getInt(TAG_LEVEL) - 1) * Config.XP_PER_LEVEL.get());
        event.setDroppedExperience((int) Math.round(event.getDroppedExperience() * mult));
    }

    // ------------------------------------------------------------------ utilidades

    private static boolean matches(List<? extends String> list, ResourceLocation id) {
        return list.contains(id.toString()) || list.contains(id.getNamespace() + ":*");
    }

    private static double baseHealth(Mob mob) {
        AttributeInstance hp = mob.getAttribute(Attributes.MAX_HEALTH);
        return hp == null ? 0.0 : hp.getBaseValue();
    }

    private static Kind kindOf(Mob mob) {
        return BossRules.kind(mob.getType(), baseHealth(mob));
    }

    private static int capFor(Mob mob) {
        return BossRules.maxLevel(mob.getType(), baseHealth(mob));
    }

    /** Nivel minimo que corresponde a unos dias efectivos (sin bonus de dimension). */
    public static int minLevelForDays(double days) {
        return Math.max(1, (int) (days / Config.DAYS_PER_LEVEL.get()));
    }

    /** Texto usado por /mobevolution nearby. */
    public static String describe(Mob mob) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(mob.getType());
        CompoundTag d = mob.getPersistentData();
        String lvl = d.contains(TAG_LEVEL) ? "Lv." + d.getInt(TAG_LEVEL) : "sin nivel";
        String base = switch (kindOf(mob)) {
            case VANILLA_BOSS -> "jefe de Minecraft";
            case MODDED_BOSS -> "jefe de mod";
            case STRONG_BOSS -> "jefe de mod fuerte";
            default -> "mob normal";
        };
        String tipo = base + " (tope " + capFor(mob) + ")";
        return id + " | " + lvl + " | vida base " + Math.round(baseHealth(mob)) + " | " + tipo;
    }

    private boolean shouldScale(Mob mob, Kind kind) {
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(mob.getType());
        if (id == null) return false;
        if (matches(Config.BLACKLIST.get(), id)) return false;
        if (kind != Kind.NORMAL) return Config.SCALE_BOSSES.get();
        return !Config.ONLY_HOSTILE.get() || mob instanceof Enemy;
    }

    // ------------------------------------------------------------------ nivel

    private int computeLevel(ServerLevel level, Mob mob) {
        // dias reales del Overworld + desplazamiento aplicado con /mobevolution days ...
        double days = DayOffsetData.effectiveDays(level.getServer());

        int min = minLevelForDays(days);
        if (level.dimension() == Level.NETHER) {
            min += Config.NETHER_BONUS.get();
        } else if (level.dimension() == Level.END) {
            min += Config.END_BONUS.get();
        }

        int max = Math.max(min, (int) Math.ceil(min * Config.MAX_MULTIPLIER.get()));
        double chance = Config.UPPER_HALF_CHANCE.get();
        double k = Math.log(0.5) / Math.log(1.0 - chance);
        double r = Math.pow(level.random.nextDouble(), k);
        int result = min + (int) Math.round((max - min) * r);

        // Tope segun el tipo: jefes de Minecraft 80, Warden 1, jefes de mods 30 (o el configurado)
        return Math.max(1, Math.min(capFor(mob), result));
    }

    // ------------------------------------------------------------------ estadisticas

    private void applyStats(Mob mob, int lvl, boolean boss, boolean heal) {
        int n = lvl - 1;
        if (n <= 0) return;
        double f = boss ? Config.BOSS_FACTOR.get() : 1.0;
        double curve = Math.pow(n, Config.EXPONENT.get());

        // Coeficientes por nivel: los del mob si se configuraron individualmente, si no los globales
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(mob.getType());
        double hpCoef = MobOverrides.coef(id, MobOverrides.Stat.HEALTH);
        double dmgCoef = MobOverrides.coef(id, MobOverrides.Stat.DAMAGE);
        double armorCoef = MobOverrides.coef(id, MobOverrides.Stat.ARMOR);
        double speedCoef = MobOverrides.coef(id, MobOverrides.Stat.SPEED);

        double hp = Math.min(hpCoef * curve * f, Config.MAX_HEALTH_MULT.get() - 1.0);
        double dmg = Math.min(dmgCoef * curve * f, Config.MAX_DAMAGE_MULT.get() - 1.0);
        double armor = Math.min(armorCoef * curve * f, Config.MAX_ARMOR_BONUS.get());
        double speed = boss ? 0.0 : Math.min(speedCoef * curve, Config.MAX_SPEED_BONUS.get());

        add(mob, Attributes.MAX_HEALTH, HEALTH_ID, "health", hp, AttributeModifier.Operation.MULTIPLY_TOTAL);
        add(mob, Attributes.MOVEMENT_SPEED, SPEED_ID, "speed", speed, AttributeModifier.Operation.MULTIPLY_TOTAL);
        add(mob, Attributes.ARMOR, ARMOR_ID, "armor", armor, AttributeModifier.Operation.ADDITION);
        mob.getPersistentData().putDouble(TAG_DMG, 1.0 + dmg);
        if (heal) mob.setHealth(mob.getMaxHealth());
    }

    private void add(Mob mob, Attribute attr, UUID id, String name, double amount, AttributeModifier.Operation op) {
        AttributeInstance inst = mob.getAttribute(attr);
        if (inst == null || amount <= 0.0) return;
        if (inst.getModifier(id) != null) inst.removeModifier(id);
        inst.addPermanentModifier(new AttributeModifier(id, "mobevolution_" + name, amount, op));
    }

    private void remove(Mob mob, Attribute attr, UUID id) {
        AttributeInstance inst = mob.getAttribute(attr);
        if (inst != null && inst.getModifier(id) != null) inst.removeModifier(id);
    }

    /** Mobs ya escalados: quita el modificador antiguo de dano y recorta los jefes que superen su tope actual. */
    private void migrate(Mob mob, CompoundTag data) {
        remove(mob, Attributes.ATTACK_DAMAGE, OLD_DAMAGE_ID);
        Kind kind = kindOf(mob);
        if (kind == Kind.NORMAL) return;
        int cap = capFor(mob);
        if (data.getInt(TAG_LEVEL) <= cap) return;

        float maxBefore = mob.getMaxHealth();
        float ratio = maxBefore > 0.0f ? mob.getHealth() / maxBefore : 1.0f;
        remove(mob, Attributes.MAX_HEALTH, HEALTH_ID);
        remove(mob, Attributes.MOVEMENT_SPEED, SPEED_ID);
        remove(mob, Attributes.ARMOR, ARMOR_ID);
        data.remove(TAG_DMG);
        data.putInt(TAG_LEVEL, cap);
        applyStats(mob, cap, true, false);
        mob.setHealth(Math.max(0.5f, ratio * mob.getMaxHealth()));
        if (mob.hasCustomName() && mob.getCustomName().getString().startsWith("[Lv.")) {
            mob.setCustomName(Component.literal("[Lv." + cap + "] ").append(mob.getType().getDescription()));
        }
    }
}
